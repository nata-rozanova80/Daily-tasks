
import sys
from typing import Optional, Dict

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QFont, QAction
from PySide6.QtWidgets import (
    QApplication, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
    QDialog, QDialogButtonBox, QLineEdit, QTextEdit, QScrollArea, QCheckBox, QFrame,
    QInputDialog, QMessageBox, QToolBar, QGridLayout, QComboBox
)

import db


class NewListDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Новая заметка / список")
        self.setMinimumWidth(420)

        name_lbl = QLabel("Название")
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Например: Покупки")

        type_lbl = QLabel("Тип")
        self.type_combo = QComboBox()
        self.type_combo.addItems(["Список (чекбоксы)", "Заметка (текст)"])

        color_lbl = QLabel("Цвет карточки")
        self.color_combo = QComboBox()
        self.color_combo.addItems(["#ffffff", "#fff7cc", "#e7f5ff", "#ffe7f0", "#e8ffe7"])

        items_lbl = QLabel("Пункты (по одному в строке) / Текст заметки")
        self.items_edit = QTextEdit()
        self.items_edit.setPlaceholderText("Молоко\nХлеб\nЯйца")

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.addWidget(name_lbl); lay.addWidget(self.title_edit)
        lay.addWidget(type_lbl); lay.addWidget(self.type_combo)
        lay.addWidget(color_lbl); lay.addWidget(self.color_combo)
        lay.addWidget(items_lbl); lay.addWidget(self.items_edit)
        lay.addWidget(btns)

    def get_data(self):
        title = self.title_edit.text().strip()
        color = self.color_combo.currentText()
        is_checklist = self.type_combo.currentIndex() == 0
        raw = [s for s in self.items_edit.toPlainText().splitlines()]
        items = [s.strip() for s in raw if s.strip()] if is_checklist else (raw and [raw[0]] or [])
        return title, items, color, is_checklist

    def accept(self):
        title, items, color, is_checklist = self.get_data()
        if not title:
            QMessageBox.warning(self, "Пустое название", "Введите название.")
            return
        super().accept()


class RoundCard(QFrame):
    def __init__(self, parent=None, color="#ffffff"):
        super().__init__(parent)
        self.setObjectName("card")
        self.setProperty("class", "card")
        self.setStyleSheet(f"QFrame#card {{ background: {color}; }}" )


class NoteCard(RoundCard):
    def __init__(self, note: dict, on_open, parent=None):
        super().__init__(parent, color=note.get("color") or "#ffffff")
        self.note_id = note["id"]
        self.on_open = on_open
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(6)

        title = QLabel(note["title"])
        f = QFont(); f.setPointSize(11); f.setBold(True)
        title.setFont(f)

        meta = QLabel(f"{note['done_count']}/{note['item_count']} ✓")
        meta.setStyleSheet("color:#6b7280;")

        layout.addWidget(title)
        layout.addWidget(meta)
        layout.addStretch()

        row = QHBoxLayout()
        pin_btn = QPushButton("📌" if note["pinned"] else "📍")
        pin_btn.setFixedHeight(28)
        pin_btn.clicked.connect(self._toggle_pin)
        arch_btn = QPushButton("🗄️")
        arch_btn.setFixedHeight(28)
        arch_btn.clicked.connect(self._archive)
        open_btn = QPushButton("Открыть")
        open_btn.setFixedHeight(28)
        open_btn.clicked.connect(lambda: self.on_open(self.note_id))
        row.addWidget(pin_btn); row.addWidget(arch_btn); row.addStretch(); row.addWidget(open_btn)
        layout.addLayout(row)

    def _toggle_pin(self):
        w = self.window()
        if hasattr(w, "toggle_pin"):
            w.toggle_pin(self.note_id)

    def _archive(self):
        w = self.window()
        if hasattr(w, "archive_note"):
            w.archive_note(self.note_id)


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Checklist Notes — Xiaomi Notes style")
        self.resize(1100, 700)

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(10)

        top = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Поиск по названию и пунктам...")
        self.search_edit.textChanged.connect(self._reload_grid)

        self.new_btn = QPushButton("＋ Новая")
        self.new_btn.clicked.connect(self._create_new)

        self.show_archived = QPushButton("Архив")
        self.show_archived.setCheckable(True)
        self.show_archived.toggled.connect(self._reload_grid)

        top.addWidget(self.search_edit)
        top.addWidget(self.show_archived)
        top.addWidget(self.new_btn)

        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True)
        self.grid_host = QWidget()
        self.grid = QGridLayout(self.grid_host)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setHorizontalSpacing(12); self.grid.setVerticalSpacing(12)
        self.scroll.setWidget(self.grid_host)

        self.detail_title = QLabel("Выберите заметку")
        f2 = QFont(); f2.setPointSize(13); f2.setBold(True); self.detail_title.setFont(f2)

        self.detail_toolbar = QToolBar()
        self.add_item_action = QAction("Добавить пункт", self); self.add_item_action.triggered.connect(self._add_item)
        self.reset_action = QAction("Сбросить отмеченные", self); self.reset_action.triggered.connect(self._reset_checked)
        self.pin_action = QAction("Закрепить/Открепить", self); self.pin_action.triggered.connect(self._toggle_pin_current)
        self.archive_action = QAction("В архив/из архива", self); self.archive_action.triggered.connect(self._toggle_archive_current)
        for a in (self.add_item_action, self.reset_action, self.pin_action, self.archive_action):
            self.detail_toolbar.addAction(a)

        self.items_container = QWidget()
        self.items_layout = QVBoxLayout(self.items_container)
        self.items_layout.setContentsMargins(6, 6, 6, 6); self.items_layout.setSpacing(8); self.items_layout.addStretch()
        self.detail_scroll = QScrollArea(); self.detail_scroll.setWidgetResizable(True); self.detail_scroll.setWidget(self.items_container)

        panes = QHBoxLayout()
        left = QVBoxLayout(); left.addLayout(top); left.addWidget(self.scroll, 1)

        right_card = QFrame(); right_card.setObjectName("card")
        right_card.setStyleSheet("QFrame#card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;}")
        right = QVBoxLayout(right_card); right.setContentsMargins(16,16,16,16)
        right.addWidget(self.detail_title); right.addWidget(self.detail_toolbar); right.addWidget(self.detail_scroll, 1)

        panes.addLayout(left, 2); panes.addWidget(right_card, 3)
        root.addLayout(panes, 1)

        self.active_list_id: Optional[int] = None
        self.checkbox_map: Dict[int, QCheckBox] = {}

        self._apply_styles()
        self._reload_grid()

    def _apply_done_style(self, checkbox: QCheckBox, checked: bool) -> None:
        f = checkbox.font(); f.setStrikeOut(checked); checkbox.setFont(f)
        checkbox.setStyleSheet("QCheckBox#todo { color: %s; }" % ("#6b7280" if checked else "#1f2937"))

    def _apply_styles(self):
        self.setStyleSheet("""
            QWidget { background: qlineargradient(x1:0,y1:0, x2:0, y2:1, stop:0 #f6f8fb, stop:1 #eaeef5);
                      font-family: 'Segoe UI', 'Roboto', sans-serif; font-size: 12.5pt; color: #1f2937; }
            QFrame#card { background:#ffffff; border:1px solid #e5e7eb; border-radius:16px; }
            QLineEdit { border: 1px solid #e5e7eb; border-radius: 12px; padding: 8px 10px; background:#f9fafb; }
            QPushButton { background: qlineargradient(x1:0,y1:0, x2:0, y2:1, stop:0 #4f46e5, stop:1 #4338ca);
                          border:0; color:#fff; padding:8px 12px; border-radius:12px; font-weight:600; }
            QToolBar { background:#f8fafc; border:1px solid #e5e7eb; border-radius:12px; padding:6px; }
            QToolBar QToolButton { padding:8px 12px; border-radius:10px; background:#ffffff; border:1px solid #e5e7eb; margin-right:8px; }
            QCheckBox#todo::indicator { width:22px; height:22px; }
            QCheckBox#todo { padding:8px 10px; background:#fff; border:1px solid #e5e7eb; border-radius:12px; }
        """)

    def _reload_grid(self):
        for i in reversed(range(self.grid.count())):
            w = self.grid.itemAt(i).widget()
            if w: w.deleteLater()

        include_arch = self.show_archived.isChecked()
        q = self.search_edit.text().strip() or None
        notes = db.get_lists(include_archived=include_arch, include_deleted=False, query=q)

        cols = 3; row = col = 0
        for n in notes:
            card = NoteCard(n, on_open=self._open_note, parent=self.grid_host)
            card.setMinimumSize(220, 140)
            self.grid.addWidget(card, row, col)
            col += 1
            if col >= cols:
                col = 0; row += 1

        if self.active_list_id and not any(n["id"] == self.active_list_id for n in notes):
            self._clear_detail()

    def _clear_detail(self):
        self.detail_title.setText("Выберите заметку")
        self.active_list_id = None
        while self.items_layout.count() > 1:
            item = self.items_layout.takeAt(0)
            w = item.widget(); 
            if w: w.deleteLater()
        self.checkbox_map.clear()

    def _open_note(self, list_id: int):
        notes = db.get_lists(include_archived=True, include_deleted=False)
        note = next((n for n in notes if n["id"] == list_id), None)
        if not note: return
        self.active_list_id = list_id
        self.detail_title.setText(note["title"])

        while self.items_layout.count() > 1:
            item = self.items_layout.takeAt(0)
            w = item.widget()
            if w: w.deleteLater()
        self.checkbox_map.clear()

        items = db.get_items(list_id)
        if not items:
            hint = QLabel("Пока нет пунктов. Используйте «Добавить пункт».")
            hint.setObjectName("hint"); self.items_layout.insertWidget(0, hint)
        else:
            for it in items:
                cb = QCheckBox(it["text"]); cb.setObjectName("todo")
                cb.setChecked(bool(it["checked"]))
                def on_state_changed(state, iid=it["id"], _cb=cb):
                    db.set_item_checked(iid, state == Qt.Checked)
                    self._apply_done_style(_cb, state == Qt.Checked)
                    self._reload_grid()
                cb.stateChanged.connect(on_state_changed)
                self._apply_done_style(cb, cb.isChecked())
                self.items_layout.insertWidget(self.items_layout.count()-1, cb)
                self.checkbox_map[it["id"]] = cb

    def _create_new(self):
        dlg = NewListDialog(self)
        if dlg.exec():
            title, items, color, is_checklist = dlg.get_data()
            list_id = db.create_list(title, items if is_checklist else [], color=color, pinned=False)
            self._reload_grid(); self._open_note(list_id)

    def _add_item(self):
        if not self.active_list_id:
            QMessageBox.information(self, "Нет заметки", "Сначала откройте заметку/список.")
            return
        text, ok = QInputDialog.getText(self, "Новый пункт", "Текст пункта:")
        if not ok or not text.strip():
            return
        item_id = db.add_item(self.active_list_id, text.strip())
        cb = QCheckBox(text.strip()); cb.setObjectName("todo"); cb.setChecked(False)
        def on_state_changed(state, iid=item_id, _cb=cb):
            db.set_item_checked(iid, state == Qt.Checked)
            self._apply_done_style(_cb, state == Qt.Checked)
            self._reload_grid()
        cb.stateChanged.connect(on_state_changed)
        self._apply_done_style(cb, False)
        self.items_layout.insertWidget(self.items_layout.count()-1, cb)
        self.checkbox_map[item_id] = cb

    def _reset_checked(self):
        if not self.active_list_id: return
        db.uncheck_checked_items(self.active_list_id)
        for cb in self.checkbox_map.values():
            if cb.isChecked():
                cb.blockSignals(True); cb.setChecked(False); cb.blockSignals(False)
                self._apply_done_style(cb, False)
        self._reload_grid()

    def toggle_pin(self, list_id: int):
        lists = db.get_lists(include_archived=True, include_deleted=False)
        note = next((n for n in lists if n["id"] == list_id), None)
        if not note: return
        db.set_pinned(list_id, not bool(note["pinned"]))
        self._reload_grid()

    def archive_note(self, list_id: int):
        lists = db.get_lists(include_archived=True, include_deleted=False)
        note = next((n for n in lists if n["id"] == list_id), None)
        if not note: return
        db.set_archived(list_id, not bool(note["archived"]))
        self._reload_grid()

    def _toggle_pin_current(self):
        if self.active_list_id:
            self.toggle_pin(self.active_list_id)

    def _toggle_archive_current(self):
        if self.active_list_id:
            self.archive_note(self.active_list_id)


def main():
    app = QApplication(sys.argv)
    db.get_conn()
    w = MainWindow()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
