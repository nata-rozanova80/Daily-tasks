
import os
import sys
import sqlite3
from pathlib import Path
from typing import List, Dict, Any, Optional

_CONN = None

def _app_dir() -> Path:
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))
        path = Path(base) / "ChecklistNotes"
    elif sys.platform == "darwin":
        path = Path.home() / "Library" / "Application Support" / "ChecklistNotes"
    else:
        path = Path.home() / ".local" / "share" / "ChecklistNotes"
    path.mkdir(parents=True, exist_ok=True)
    return path

def db_path() -> Path:
    return _app_dir() / "app.db"

def get_conn() -> sqlite3.Connection:
    global _CONN
    if _CONN is None:
        _CONN = sqlite3.connect(db_path())
        _CONN.row_factory = sqlite3.Row
        _CONN.execute("PRAGMA foreign_keys=ON;")
        init_db(_CONN)
    return _CONN

def _column_exists(conn: sqlite3.Connection, table: str, column: str) -> bool:
    cur = conn.execute(f"PRAGMA table_info({table})")
    return any(r["name"] == column for r in cur.fetchall())

def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        '''
        CREATE TABLE IF NOT EXISTS lists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            list_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            checked INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(list_id) REFERENCES lists(id) ON DELETE CASCADE
        );
        '''
    )
    if not _column_exists(conn, "lists", "pinned"):
        conn.execute("ALTER TABLE lists ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0")
    if not _column_exists(conn, "lists", "archived"):
        conn.execute("ALTER TABLE lists ADD COLUMN archived INTEGER NOT NULL DEFAULT 0")
    if not _column_exists(conn, "lists", "color"):
        conn.execute("ALTER TABLE lists ADD COLUMN color TEXT DEFAULT '#ffffff'")
    if not _column_exists(conn, "lists", "deleted_at"):
        conn.execute("ALTER TABLE lists ADD COLUMN deleted_at TIMESTAMP")
    conn.commit()

def _touch_updated(list_id: int) -> None:
    conn = get_conn()
    conn.execute("UPDATE lists SET updated_at = CURRENT_TIMESTAMP WHERE id=?", (list_id,))
    conn.commit()

def create_list(title: str, items: List[str], color: str = "#ffffff", pinned: bool=False) -> int:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO lists(title, color, pinned) VALUES (?, ?, ?)", (title, color, 1 if pinned else 0))
    list_id = cur.lastrowid
    if items:
        cur.executemany(
            "INSERT INTO items(list_id, text, checked) VALUES (?, ?, 0)",
            [(list_id, t.strip()) for t in items if t.strip()]
        )
    conn.commit()
    return list_id

def get_lists(include_archived: bool=False, include_deleted: bool=False, query: Optional[str]=None) -> List[Dict[str, Any]]:
    conn = get_conn()
    where = ["1=1"]
    if not include_archived:
        where.append("archived=0")
    if not include_deleted:
        where.append("deleted_at IS NULL")
    params = []
    if query:
        where.append("(title LIKE ? OR EXISTS (SELECT 1 FROM items i WHERE i.list_id=l.id AND i.text LIKE ?))")
        like = f"%{query}%"
        params.extend([like, like])
    sql = f"""
        SELECT l.id, l.title, l.created_at, l.updated_at, l.pinned, l.archived, l.color,
               (SELECT COUNT(*) FROM items i WHERE i.list_id=l.id) AS item_count,
               (SELECT COUNT(*) FROM items i WHERE i.list_id=l.id AND i.checked=1) AS done_count
        FROM lists l
        WHERE {' AND '.join(where)}
        ORDER BY l.pinned DESC, l.updated_at DESC, l.created_at DESC
    """
    cur = conn.execute(sql, params)
    return [dict(row) for row in cur.fetchall()]

def get_items(list_id: int) -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.execute(
        "SELECT id, text, checked FROM items WHERE list_id=? ORDER BY id ASC",
        (list_id,)
    )
    return [dict(row) for row in cur.fetchall()]

def set_item_checked(item_id: int, checked: bool) -> None:
    conn = get_conn()
    conn.execute("UPDATE items SET checked=? WHERE id=?", (1 if checked else 0, item_id))
    cur = conn.execute("SELECT list_id FROM items WHERE id=?", (item_id,))
    row = cur.fetchone()
    if row:
        _touch_updated(row["list_id"])
    conn.commit()

def uncheck_checked_items(list_id: int) -> None:
    conn = get_conn()
    conn.execute("UPDATE items SET checked=0 WHERE list_id=? AND checked=1", (list_id,))
    _touch_updated(list_id)
    conn.commit()

def add_item(list_id: int, text: str) -> int:
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO items(list_id, text, checked) VALUES (?, ?, 0)",
        (list_id, text.strip())
    )
    _touch_updated(list_id)
    conn.commit()
    return cur.lastrowid

def set_pinned(list_id: int, pinned: bool) -> None:
    conn = get_conn()
    conn.execute("UPDATE lists SET pinned=? WHERE id=?", (1 if pinned else 0, list_id))
    _touch_updated(list_id)
    conn.commit()

def set_archived(list_id: int, archived: bool) -> None:
    conn = get_conn()
    conn.execute("UPDATE lists SET archived=? WHERE id=?", (1 if archived else 0, list_id))
    _touch_updated(list_id)
    conn.commit()

def set_color(list_id: int, color: str) -> None:
    conn = get_conn()
    conn.execute("UPDATE lists SET color=? WHERE id=?", (color, list_id))
    _touch_updated(list_id)
    conn.commit()

def soft_delete(list_id: int) -> None:
    conn = get_conn()
    conn.execute("UPDATE lists SET deleted_at=CURRENT_TIMESTAMP WHERE id=?", (list_id,))
    conn.commit()

def rename_list(list_id: int, title: str) -> None:
    conn = get_conn()
    conn.execute("UPDATE lists SET title=? WHERE id=?", (title, list_id))
    _touch_updated(list_id)
    conn.commit()
