
import os
import sys
import sqlite3
from pathlib import Path
from typing import List, Dict, Any

_CONN = None

def _app_dir() -> Path:
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))
        path = Path(base) / "ChecklistNotes"
    elif sys.platform == "darwin":
        path = Path.home() / "Library" / "Application Support" / "ChecklistNotes"
    else:
        path = Path.home() / ".local" / "share" / "ChecklistNotes"
    path.mkdir(parents=True, exist_ok=True)
    return path

def db_path() -> Path:
    return _app_dir() / "app.db"

def get_conn() -> sqlite3.Connection:
    global _CONN
    if _CONN is None:
        _CONN = sqlite3.connect(db_path())
        _CONN.row_factory = sqlite3.Row
        _CONN.execute("PRAGMA foreign_keys=ON;")
        init_db(_CONN)
    return _CONN

def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        '''
        CREATE TABLE IF NOT EXISTS lists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            list_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            checked INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(list_id) REFERENCES lists(id) ON DELETE CASCADE
        );
        '''
    )
    conn.commit()

def create_list(title: str, items: List[str]) -> int:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO lists(title) VALUES (?)", (title,))
    list_id = cur.lastrowid
    cur.executemany(
        "INSERT INTO items(list_id, text, checked) VALUES (?, ?, 0)",
        [(list_id, t.strip()) for t in items if t.strip()]
    )
    conn.commit()
    return list_id

def get_lists() -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.execute("SELECT id, title, created_at FROM lists ORDER BY created_at DESC")
    return [dict(row) for row in cur.fetchall()]

def get_items(list_id: int) -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.execute(
        "SELECT id, text, checked FROM items WHERE list_id=? ORDER BY id ASC",
        (list_id,)
    )
    return [dict(row) for row in cur.fetchall()]

def set_item_checked(item_id: int, checked: bool) -> None:
    conn = get_conn()
    conn.execute("UPDATE items SET checked=? WHERE id=?", (1 if checked else 0, item_id))
    conn.commit()

def uncheck_checked_items(list_id: int) -> None:
    conn = get_conn()
    conn.execute("UPDATE items SET checked=0 WHERE list_id=? AND checked=1", (list_id,))
    conn.commit()

def add_item(list_id: int, text: str) -> int:
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO items(list_id, text, checked) VALUES (?, ?, 0)",
        (list_id, text.strip())
    )
    conn.commit()
    return cur.lastrowid
