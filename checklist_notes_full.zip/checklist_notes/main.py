
import sys
from typing import Optional, Dict

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QAction
from PySide6.QtWidgets import (
    QApplication, QWidget, QHBoxLayout, QVBoxLayout, QListWidget, QLabel, QPushButton,
    QDialog, QDialogButtonBox, QLineEdit, QTextEdit, QScrollArea, QCheckBox, QFrame,
    QInputDialog, QMessageBox, QListWidgetItem, QToolBar
)

import db


class NewListDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Новый список")
        self.setMinimumWidth(420)

        title_lbl = QLabel("Название списка")
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Например: Сборы в поездку")

        items_lbl = QLabel("Пункты (по одному в строке)")
        self.items_edit = QTextEdit()
        self.items_edit.setPlaceholderText("Паспорт\nБилеты\nЗарядка\nНаушники")

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.addWidget(title_lbl)
        lay.addWidget(self.title_edit)
        lay.addWidget(items_lbl)
        lay.addWidget(self.items_edit)
        lay.addWidget(btns)

    def get_data(self):
        title = self.title_edit.text().strip()
        items = [s.strip() for s in self.items_edit.toPlainText().splitlines() if s.strip()]
        return title, items

    def accept(self):
        title, items = self.get_data()
        if not title:
            QMessageBox.warning(self, "Пустое название", "Введите название списка.")
            return
        if not items:
            res = QMessageBox.question(self, "Без пунктов?",
                                       "Вы добавляете пустой список. Продолжить?",
                                       QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if res != QMessageBox.Yes:
                return
        super().accept()


class RoundCard(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.setFrameShape(QFrame.StyledPanel)
        self.setProperty("class", "card")


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Checklist Notes")
        self.resize(980, 620)

        root = QHBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(14)

        # Sidebar (lists)
        sidebar_card = RoundCard()
        sidebar_layout = QVBoxLayout(sidebar_card)
        sidebar_layout.setContentsMargins(16, 16, 16, 16)
        sidebar_layout.setSpacing(10)

        title = QLabel("Мои списки")
        f = QFont()
        f.setPointSize(14)
        f.setBold(True)
        title.setFont(f)

        self.list_widget = QListWidget()
        self.list_widget.itemSelectionChanged.connect(self._on_list_selected)

        self.new_btn = QPushButton("＋ Новый список")
        self.new_btn.clicked.connect(self._create_new_list)

        sidebar_layout.addWidget(title)
        sidebar_layout.addWidget(self.list_widget)
        sidebar_layout.addWidget(self.new_btn)

        # Content (items)
        content_card = RoundCard()
        content_layout = QVBoxLayout(content_card)
        content_layout.setContentsMargins(16, 16, 16, 16)
        content_layout.setSpacing(10)

        self.active_title = QLabel("Выберите список")
        f2 = QFont()
        f2.setPointSize(13)
        f2.setBold(True)
        self.active_title.setFont(f2)

        # toolbar
        toolbar = QToolBar()
        self.add_item_action = QAction("Добавить пункт", self)
        self.add_item_action.triggered.connect(self._add_item)
        self.reset_action = QAction("Сбросить отмеченные", self)
        self.reset_action.triggered.connect(self._reset_checked)
        toolbar.addAction(self.add_item_action)
        toolbar.addAction(self.reset_action)

        # Scroll with checkboxes
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.items_container = QWidget()
        self.items_layout = QVBoxLayout(self.items_container)
        self.items_layout.setContentsMargins(6, 6, 6, 6)
        self.items_layout.setSpacing(8)
        self.items_layout.addStretch()
        self.scroll.setWidget(self.items_container)

        content_layout.addWidget(self.active_title)
        content_layout.addWidget(toolbar)
        content_layout.addWidget(self.scroll)

        root.addWidget(sidebar_card, 1)
        root.addWidget(content_card, 2)

        self._apply_styles()
        self._load_lists()
        self.active_list_id: Optional[int] = None
        self.checkbox_map: Dict[int, QCheckBox] = {}

    # ---- Data loading ----
    def _load_lists(self):
        self.list_widget.clear()
        for row in db.get_lists():
            item = QListWidgetItem(row["title"])
            item.setData(Qt.UserRole, row["id"])
            self.list_widget.addItem(item)

    def _load_items(self, list_id: int):
        self.active_list_id = list_id
        # Clear layout (except the stretch at the end)
        while self.items_layout.count() > 1:
            item = self.items_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        self.checkbox_map.clear()

        items = db.get_items(list_id)
        if not items:
            hint = QLabel("Список пуст. Нажмите «Добавить пункт».")
            hint.setObjectName("hint")
            self.items_layout.insertWidget(0, hint)
        else:
            for it in items:
                cb = QCheckBox(it["text"])
                cb.setChecked(bool(it["checked"]))
                cb.stateChanged.connect(lambda state, iid=it["id"]: db.set_item_checked(iid, state == Qt.Checked))
                cb.setObjectName("todo")
                self.items_layout.insertWidget(self.items_layout.count()-1, cb)
                self.checkbox_map[it["id"]] = cb

    # ---- UI actions ----
    def _on_list_selected(self):
        items = self.list_widget.selectedItems()
        if not items:
            return
        sel = items[0]
        list_id = sel.data(Qt.UserRole)
        self.active_title.setText(sel.text())
        self._load_items(list_id)

    def _create_new_list(self):
        dlg = NewListDialog(self)
        if dlg.exec():
            title, items = dlg.get_data()
            list_id = db.create_list(title, items)
            self._load_lists()
            # select the new list
            matches = self.list_widget.findItems(title, Qt.MatchExactly)
            if matches:
                self.list_widget.setCurrentItem(matches[0])
            self._load_items(list_id)

    def _add_item(self):
        if self.active_list_id is None:
            QMessageBox.information(self, "Нет списка", "Сначала выберите список.")
            return
        ok, text = QInputDialog.getText(self, "Новый пункт", "Текст пункта:")
        if not ok or not text.strip():
            return
        item_id = db.add_item(self.active_list_id, text.strip())
        cb = QCheckBox(text.strip())
        cb.setChecked(False)
        cb.stateChanged.connect(lambda state, iid=item_id: db.set_item_checked(iid, state == Qt.Checked))
        cb.setObjectName("todo")
        self.items_layout.insertWidget(self.items_layout.count()-1, cb)
        self.checkbox_map[item_id] = cb

    def _reset_checked(self):
        if self.active_list_id is None:
            return
        db.uncheck_checked_items(self.active_list_id)
        # update UI
        for cb in self.checkbox_map.values():
            if cb.isChecked():
                cb.blockSignals(True)
                cb.setChecked(False)
                cb.blockSignals(False)

    # ---- Style ----
    def _apply_styles(self):
        self.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0,y1:0, x2:0, y2:1, stop:0 #f6f8fb, stop:1 #eaeef5);
                font-family: 'Segoe UI', 'Roboto', sans-serif;
                font-size: 12.5pt;
                color: #1f2937;
            }
            QLabel#hint {
                color: #6b7280;
                padding: 8px 10px;
                border-radius: 10px;
                background: #f3f4f6;
            }
            QFrame#card {
                background: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 16px;
            }
            QListWidget {
                border: none;
                background: transparent;
                outline: none;
            }
            QListWidget::item {
                padding: 8px 10px;
                margin: 4px;
                border-radius: 10px;
            }
            QListWidget::item:selected {
                background: #e0e7ff;
                color: #111827;
            }
            QLineEdit, QTextEdit {
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                padding: 8px 10px;
                background: #f9fafb;
            }
            QPushButton {
                background: qlineargradient(x1:0,y1:0, x2:0, y2:1, stop:0 #4f46e5, stop:1 #4338ca);
                border: 0;
                color: white;
                padding: 10px 14px;
                border-radius: 14px;
                font-weight: 600;
            }
            QPushButton:hover {
                filter: brightness(1.08);
            }
            QPushButton:disabled {
                background: #c7c9d1;
            }
            QToolBar {
                background: #f8fafc;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                padding: 6px;
            }
            QToolBar QToolButton {
                padding: 8px 12px;
                border-radius: 10px;
                background: #ffffff;
                border: 1px solid #e5e7eb;
                margin-right: 8px;
            }
            QCheckBox#todo::indicator {
                width: 22px; height: 22px;
            }
            QCheckBox#todo {
                padding: 8px 10px;
                background: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
            }
        """)

def main():
    app = QApplication(sys.argv)
    # ensure DB is ready
    db.get_conn()
    w = MainWindow()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
